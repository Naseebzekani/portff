import 'package:flutter/material.dart';

class GetInTouchMob extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
